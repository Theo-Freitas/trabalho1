package com.example.myapplication.ui.theme

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        usernameEditText = findViewById(R.id.usernameEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        loginButton = findViewById(R.id.loginButton)

        loginButton.setOnClickListener {
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Lógica de autenticação simples (exemplo)
            if (isValidCredentials(username, password)) {
                // Se as credenciais são válidas, inicie a MainActivity
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish() //
            } else {

            }
        }
    }

    private fun isValidCredentials(username: String, password: String): Boolean {
        return username == "usuario" && password == "senha"
    }
}